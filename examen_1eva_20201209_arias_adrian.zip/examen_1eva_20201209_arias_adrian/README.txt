Adrián Arias: Prueba práctica examen entorno servidor 09/12/2020

Link al repositorio de Github: https://github.com/AdriAriasAlonso/examen_1eva_20201209_arias_adrian.git
Direccion al servidor remoto de AWS: ssh ubuntu@aarias.ddns.net CONTRASEÑA: adrian

Ejercicio 4:

Para conseguir que el precio se imprima con el símbolo del dólar a la izquierda del mismo, debemos
modificar el archivo read_template.php y en la línea 38 debemos cambiar la línea existente por
echo "<td>\${$price}</td>"; de esta forma conseguimos imprimir el símbolo a la izquierda del precio.

Ejercicio 5:

Las  imagenes son una propiedad mas de un producto, el cual es un objeto. Al crear un objeto, la funcion create() convierte esa imagen utilizando la funcion htmlspecialchars a una entidad HTML, con lo cual, la imagen se queda guardada como una cadena HTML de tipo VARCHAR de 512 de length en la base de datos.

Antes de aceptar
una imagen, hay que validarla, y hay que validar varias cosas: Identificar si es una imagen real o
falsa, limitar los tipos de archivo que se pueden subir, prevenir archivos multiples en el 
servidor, denegar aquellos archivos que son demasiado grandes, y asegurarse de que el directorio
"uploads" existe. En la carpeta "objects" y en el archivo product.php, a partir de la linea 218 se hacen las
comprobaciones necesarias para poder validar imágenes.

Para poder recuperar esa imagen, se hace uso de una query de mysql en la cual seleccionamos la imagen como propiedad del producto

Ejercicio 6:

En update_product.php, para poder actualizar las imagenes de un producto, debemos añadir la propiedad image en la linea 42 para poder cambiar la misma, añadir al formulario de update_product.php la categoria de "Photo" y el input de tipo "file", en la linea 79.